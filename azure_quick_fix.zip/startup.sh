#!/bin/bash
echo "Starting FoodXchange minimal app..."
python -m uvicorn app:app --host 0.0.0.0 --port $PORT
