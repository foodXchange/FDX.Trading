from fastapi import FastAPI, Response
from datetime import datetime
import os

app = FastAPI()

@app.get("/")
async def root():
    return {
        "message": "FoodXchange API",
        "version": "1.0.0",
        "status": "operational",
        "timestamp": datetime.now().isoformat()
    }

@app.get("/health")
async def health():
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

@app.head("/health")
async def health_head():
    return Response(status_code=200)

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8000))
    uvicorn.run(app, host="0.0.0.0", port=port)
