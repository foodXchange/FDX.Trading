﻿from fastapi import FastAPI, Response
from datetime import datetime
import os
import sys

app = FastAPI(title="FoodXchange API")

@app.get("/health")
async def health():
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "environment": os.environ.get("ENVIRONMENT", "unknown")
    }

@app.head("/health")
async def health_head():
    return Response(status_code=200)

@app.get("/")
async def root():
    return {
        "message": "FoodXchange API",
        "version": "1.0.0",
        "timestamp": datetime.now().isoformat(),
        "endpoints": ["/health", "/docs", "/redoc"]
    }

@app.head("/")
async def root_head():
    return Response(status_code=200)

@app.get("/health/simple")
async def health_simple():
    return Response(content="OK", media_type="text/plain", status_code=200)

@app.head("/health/simple")
async def health_simple_head():
    return Response(status_code=200)

# Add error handler
@app.exception_handler(Exception)
async def exception_handler(request, exc):
    return {
        "error": str(exc),
        "type": type(exc).__name__,
        "path": str(request.url)
    }

if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run("app:app", host="0.0.0.0", port=port, reload=False)
