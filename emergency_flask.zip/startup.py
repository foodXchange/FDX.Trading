﻿#!/usr/bin/env python
import os
import sys
from application import app

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    app.run(host="0.0.0.0", port=port)
