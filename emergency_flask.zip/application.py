﻿from flask import Flask, jsonify, render_template_string
from datetime import datetime
import os

app = Flask(__name__)

# HTML template for home page
HOME_TEMPLATE = '''
<!DOCTYPE html>
<html>
<head>
    <title>FoodXchange</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            padding: 50px;
            background: #f5f5f5;
        }
        .container {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            max-width: 600px;
            margin: 0 auto;
        }
        h1 { color: #ff6b35; }
        .status {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }
        a {
            color: #ff6b35;
            text-decoration: none;
            margin: 0 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>FoodXchange</h1>
        <p>AI-Powered Food Sourcing Platform</p>
        <div class="status">
            <strong>System Status:</strong> Operational (Emergency Mode)
        </div>
        <p>
            <a href="/health">Health Check</a> |
            <a href="/health/simple">Simple Health</a> |
            <a href="/health/detailed">Detailed Health</a>
        </p>
    </div>
</body>
</html>
'''

@app.route('/')
def home():
    return render_template_string(HOME_TEMPLATE)

@app.route('/health')
@app.route('/health/simple')
def health():
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat()
    })

@app.route('/health/detailed')
def health_detailed():
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'version': '1.0.0',
        'mode': 'emergency',
        'platform': 'Azure App Service',
        'message': 'Running in emergency Flask mode'
    })

@app.route('/health/advanced')
def health_advanced():
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'version': '1.0.0',
        'mode': 'emergency',
        'services': {
            'application': 'healthy',
            'database': 'not_connected'
        }
    })

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8000))
    app.run(host='0.0.0.0', port=port)
